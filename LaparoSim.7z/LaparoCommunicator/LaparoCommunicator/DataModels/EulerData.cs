﻿namespace LaparoCommunicator
{
    public class EulerData
    {
        public double[] LeftAngles { get; set; }
        public double[] RightAngles { get; set; }
        public override string ToString()
        {
            return $"Left: {string.Join(" ", LeftAngles)}\tRight: {string.Join(" ", RightAngles)}";
        }
    }
}
