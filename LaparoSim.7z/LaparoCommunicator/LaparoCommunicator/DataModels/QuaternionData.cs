﻿namespace LaparoCommunicator
{
    public class QuaternionData
    {
        public double[] LeftQuaternion { get; set; }
        public double[] RightQuaternion { get; set; }
        public override string ToString()
        {
            return $"Left: {string.Join(" ", LeftQuaternion)}\tRight: {string.Join(" ", RightQuaternion)}";
        }
    }
}
